#version 150

in vec3 Position;
out vec2 texCoord;

void main() {
    // Full-screen triangle. The exact vertex format / pipeline hookup is
    // owned by Minecraft's post-effect pipeline, not by this file alone.
    vec2 p = Position.xy;
    texCoord = p * 0.5 + 0.5;
    gl_Position = vec4(p, 0.0, 1.0);
}
