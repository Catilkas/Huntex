#version 150

uniform vec2 ScreenSize;
uniform float Time;
uniform vec2 Cursor;
uniform float HoverPlay;
uniform float HoverSettings;
uniform float HoverQuit;

in vec2 texCoord;
out vec4 fragColor;

float roundedBox(vec2 p, vec2 halfSize, float radius) {
    vec2 q = abs(p) - halfSize + radius;
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
}

float button(vec2 uv, vec2 center, vec2 size, float hovered) {
    float d = roundedBox(uv - center, size, 0.012);
    float pulse = 0.5 + 0.5 * sin(Time * 5.0);
    float glow = hovered * (0.10 + 0.08 * pulse);
    float fill = 1.0 - smoothstep(0.0, 0.004, d);
    return fill * (0.22 + glow);
}

void main() {
    vec2 uv = texCoord;
    vec3 col = vec3(0.025, 0.035, 0.065);

    // Subtle animated background.
    float grid = 0.5 + 0.5 * sin(uv.x * 24.0 + Time * 0.25)
                            * sin(uv.y * 18.0 - Time * 0.18);
    col += vec3(0.015, 0.025, 0.045) * grid;

    float p = button(uv, vec2(0.5, 0.47), vec2(0.12, 0.042), HoverPlay);
    float s = button(uv, vec2(0.5, 0.59), vec2(0.12, 0.042), HoverSettings);
    float q = button(uv, vec2(0.5, 0.71), vec2(0.12, 0.042), HoverQuit);

    col = mix(col, vec3(0.12, 0.42, 0.95), p);
    col = mix(col, vec3(0.12, 0.42, 0.95), s);
    col = mix(col, vec3(0.12, 0.42, 0.95), q);

    // Cursor marker.
    float cursorDist = length((uv - Cursor) * vec2(ScreenSize.x / ScreenSize.y, 1.0));
    float cursor = 1.0 - smoothstep(0.003, 0.006, cursorDist);
    col = mix(col, vec3(1.0), cursor);

    fragColor = vec4(col, 1.0);
}
