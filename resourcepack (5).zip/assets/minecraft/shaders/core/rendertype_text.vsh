#version 330
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
in vec3 Position;
in vec4 Color;
in vec2 UV0;
uniform sampler2D Sampler0;
out vec4 vertexColor;
out vec2 texCoord0;
#ifdef IS_GUI
const vec2 TOP = vec2(0.);
const vec2 LEFT = vec2(0.);
const vec2 MENU_UV_OFFSETS[4] = vec2[](vec2(-0.5), vec2(-0.5, 0.5), vec2(0.5), vec2(0.5, -0.5));
const vec2 MENU_POSITIONS[4] = vec2[](vec2(0.), vec2(0., 1.), vec2(1.), vec2(1., 0.));
const ivec2 MENU_TEX_SIZE = ivec2(2048, 2048);
const float MENU_SIZE = 180.0;
const vec2 MENU_PADDING = vec2(0.0, 0.0);
const vec2 MENU_ALIGN = vec2(0.0, 0.0);
#endif
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;
    texCoord0 = UV0;
#ifdef IS_GUI
    if (textureSize(Sampler0, 0).rg == MENU_TEX_SIZE) {
        vec2 position = MENU_SIZE * (MENU_ALIGN + MENU_POSITIONS[gl_VertexID & 3]) +
                        (MENU_PADDING * sign(MENU_ALIGN + 0.5));
        gl_Position = ProjMat * ModelViewMat * vec4(position, 0., 1.) +
                      vec4(vec2(-2., 2.) * MENU_ALIGN, 0., 0.);
        texCoord0 = vec2(0.5) + MENU_UV_OFFSETS[gl_VertexID & 3];
    }
}
