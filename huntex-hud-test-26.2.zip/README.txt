HUNTEX HUD TEST — Minecraft 26.2
================================

What this is
------------
A test resource-pack scaffold based on the 26.2 core-shader technique:
a texture is rendered in the GUI when a player-head texture component is
included in a GUI text component (for example a bossbar title).

Important
---------
This pack is NOT a standalone server and does not start a public server.
You still run your existing Minestom 26.2 server and send this pack to players.
The pack shader replaces rendertype_text core shaders, so test it separately
from other packs that also modify those shaders.

Install
-------
1. Put this folder's contents into your resource pack ZIP (pack.mcmeta at root).
2. Host the ZIP at a direct HTTPS URL and calculate its SHA-1.
3. Set that URL and SHA-1 in your existing Minestom ResourcePackInfo.
4. Add a GUI text component that contains a player-head texture reference:
   huntex:textures/gui/menu
   (the exact Adventure/Minestom component builder depends on the Adventure
   version bundled with your project).
5. Put that component in a BossBar title or another GUI text location.

Texture path:
  assets/huntex/textures/gui/menu.png
Resource location:
  huntex:gui/menu

Shader:
  assets/minecraft/shaders/core/rendertype_text.vsh
  assets/minecraft/shaders/core/rendertype_text.fsh

Notes
-----
- This is a first-pass static HUD texture test, not yet a clickable menu.
- Mouse position is not exposed to a vanilla server as raw screen coordinates.
  Button hit-testing and click routing need a separate interaction design.
- The 2048x2048 image is sampled as a GUI texture. If the game version changes
  shader interfaces or pack format, shader/metadata may need adjustment.
- The upstream 26.2 technique documents rendering a texture via a player-head
  texture component in BossBar, ActionBar, scoreboard, or tab:
  https://github.com/thecodertommy/minimap
